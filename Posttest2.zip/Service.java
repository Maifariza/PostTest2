package com.mycompany.posttest1.service;

import com.mycompany.posttest1.model.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Service {
    private final List<Model> koleksi = new ArrayList<>();
    private int nextId = 1;

    private final Scanner in;

    public Service(Scanner in) {
        this.in = in;
    }

    public void seedAwal() {
        koleksi.add(new Model(nextId++, "Vas Dinasti Ming", "Keramik", "Tiongkok", 1560,
                "Porselen", "Baik", "Lelang", 120_000_000));
        koleksi.add(new Model(nextId++, "Koin Perak VOC", "Koin", "Nusantara", 1750,
                "Perak", "Sedang", "Warisan", 8_500_000));
        koleksi.add(new Model(nextId++, "Meja Ukir Jepara", "Mebel", "Jepara", 1800,
                "Kayu Jati", "Baik", "Warisan", 55_000_000));
        koleksi.add(new Model(nextId++, "Naskah Kuno Sansekerta", "Naskah", "India", 1200,
                "Lontar", "Sedang", "Hibah", 200_000_000));
        koleksi.add(new Model(nextId++, "Guci Dinasti Qing", "Keramik", "Tiongkok", 1700,
                "Porselen", "Baik", "Lelang", 150_000_000));
        koleksi.add(new Model(nextId++, "Topeng Kayu Bali", "Seni", "Bali", 1850,
                "Kayu", "Baik", "Warisan", 25_000_000));
        koleksi.add(new Model(nextId++, "Lukisan Raden Saleh", "Lukisan", "Jawa", 1849,
                "Kanvas & Cat Minyak", "Sedang", "Lelang", 500_000_000));
        koleksi.add(new Model(nextId++, "Cincin Emas Majapahit", "Perhiasan", "Majapahit", 1400,
                "Emas", "Baik", "Hibah", 75_000_000));
        koleksi.add(new Model(nextId++, "Keris Pusaka", "Senjata", "Jawa", 1600,
                "Besi Pamor", "Baik", "Warisan", 120_000_000));
        koleksi.add(new Model(nextId++, "Piring Keramik Belanda", "Keramik", "Belanda", 1750,
                "Keramik Glasir", "Baik", "Warisan", 50_000_000));
        koleksi.add(new Model(nextId++, "Topeng Opera Beijing", "Seni", "Tiongkok", 1800,
                "Kayu", "Baik", "Lelang", 70_000_000));
        koleksi.add(new Model(nextId++, "Pedang Ottoman", "Senjata", "Turki", 1650,
                "Baja Polos", "Baik", "Warisan", 95_000_000));
        koleksi.add(new Model(nextId++, "Jam Saku Edwardian", "Aksesoris", "Inggris", 1905,
                "Emas & Kaca", "Baik", "Lelang", 42_000_000));

    }

    public void tambahBarang() {
        System.out.println("\n........................................");
        System.out.println("      TAMBAH BARANG AntikAesthetic     ");
        System.out.println("........................................");
        String nama = inputString("Nama barang");
        String kategori = inputString("Kategori (mis. Keramik/Koin/Lukisan/Perhiasan)");
        String asal = inputString("Asal/Asal-usul");
        int tahun = inputInt("Tahun pembuatan/periode (angka)", 0, 3000);
        String material = inputString("Material/Bahan");
        String kondisi = inputString("Kondisi (Baik/Sedang/Rusak/Direstorasi)");
        String sumber = inputString("Sumber perolehan (Pembelian/Hibah/Lelang/Warisan)");
        double harga = inputDouble("Harga perolehan (angka, bisa 0 jika tidak diketahui)", 0, Double.MAX_VALUE);

        Model b = new Model(nextId++, nama, kategori, asal, tahun, material, kondisi, sumber, harga);
        koleksi.add(b);
        System.out.println("\n Berhasil menambahkan barang dengan ID: " + b.getId());
    }

    public void tampilkanSemua() {
        System.out.println("\n+-----+-----+-----+-----+-----+-----+-----+ DAFTAR KOLEKSI BARANG AntikAesthetic  +-----+-----+-----+-----+-----+-----+-----+");
        System.out.println("............................................................................................................................");
        if (koleksi.isEmpty()) {
            System.out.println("Oops.. belum ada data.");
            return;
        }

        System.out.printf(" %-4s | %-22s | %-10s | %-10s | %-5s | %-10s | %-12s | %-10s | %-12s%n ",
                "ID", "Nama", "Kategori", "Asal", "Thn", "Material", "Kondisi", "Sumber", "Harga");
        System.out.println("----+------------------------+------------+------------+-------+------------+--------------+-------------+----------------");

        for (Model b : koleksi) {
            System.out.printf("%-4d | %-22s | %-10s | %-10s | %-5d | %-10s | %-12s | %-10s | Rp. %,.0f%n",
                    b.getId(), potong(b.getNama(),22), potong(b.getKategori(),10), potong(b.getAsal(),10), b.getTahun(),
                    potong(b.getMaterial(),10), potong(b.getKondisi(),12), potong(b.getSumber(),10), b.getHargaPerolehan());
        }
    }

    public void perbaruiBarang() {
        System.out.println("\n ********** PERBARUI BARANG (berdasarkan ID) **********");
        int id = inputInt("Masukkan ID yang akan diperbarui", 1, Integer.MAX_VALUE);
        Model b = cariById(id);
        if (b == null) {
            System.out.println("Whoop... Data dengan ID " + id + " tidak ditemukan.");
            return;
        }

        System.out.println("Kosongkan input (tekan Enter) jika ingin mempertahankan nilai lama");
        System.out.println("..........................................................");

        String nama = inputStringOpsional("Nama barang", b.getNama());
        String kategori = inputStringOpsional("Kategori", b.getKategori());
        String asal = inputStringOpsional("Asal/Asal-usul", b.getAsal());
        Integer tahun = inputIntOpsional("Tahun (angka)", b.getTahun(), 0, 3000);
        String material = inputStringOpsional("Material/Bahan", b.getMaterial());
        String kondisi = inputStringOpsional("Kondisi", b.getKondisi());
        String sumber = inputStringOpsional("Sumber perolehan", b.getSumber());
        Double harga = inputDoubleOpsional("Harga perolehan (angka)", b.getHargaPerolehan(), 0, Double.MAX_VALUE);

        b.setNama(nama);
        b.setKategori(kategori);
        b.setAsal(asal);
        b.setTahun(tahun);
        b.setMaterial(material);
        b.setKondisi(kondisi);
        b.setSumber(sumber);
        b.setHargaPerolehan(harga);

        System.out.println("....... Data ID " + id + " berhasil diperbarui .......");
    }

    public void hapusBarang() {
        System.out.println("\n>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<");
        System.out.println("      HAPUS BARANG AntikAesthetic       ");
        System.out.println("--------- Cari Berdasarkan ID --------");
        System.out.println(">>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<");
        int id = inputInt("Masukkan ID yang akan dihapus", 1, Integer.MAX_VALUE);
        int idx = indexById(id);
        if (idx == -1) {
            System.out.println("Data dengan ID " + id + " tidak ditemukan.");
            return;
        }
        System.out.print("Yakin hapus ID " + id + " (y/n)? ");
        String ya = in.nextLine().trim().toLowerCase();
        if (ya.equals("y")) {
            koleksi.remove(idx);
            System.out.println("~~~~~~~~ Data ID " + id + " telah dihapus ~~~~~~~~");
        } else {
            System.out.println(" >>>>> Dibatalkan <<<<<");
        }
    }

    // SEARCH
    public void cariBarang() {
        System.out.println("\n==============================================");
        System.out.println("          CARI BARANG AntikAesthetic          ");
        System.out.println("==============================================");
        String key = inputString("Kata kunci").toLowerCase();

        List<Model> hasil = new ArrayList<>();
        for (Model b : koleksi) {
            if (b.getNama().toLowerCase().contains(key) ||
                b.getKategori().toLowerCase().contains(key) ||
                b.getAsal().toLowerCase().contains(key)) {
                hasil.add(b);
            }
        }

        if (hasil.isEmpty()) {
            System.out.println("Oops.. Tidak ada hasil untuk: " + key);
            return;
        }

        System.out.printf("%-4s | %-22s | %-10s | %-10s | %-5s | %-10s | %-12s | %-10s | %-12s%n",
                "ID", "Nama", "Kategori", "Asal", "Thn", "Material", "Kondisi", "Sumber", "Harga");
        System.out.println("-----+------------------------+------------+------------+------+------------+--------------+------------+--------------");
        for (Model b : hasil) {
            System.out.printf("%-4d | %-22s | %-10s | %-10s | %-5d | %-10s | %-12s | %-10s | Rp%,.0f%n",
                    b.getId(), potong(b.getNama(),22), potong(b.getKategori(),10), potong(b.getAsal(),10), b.getTahun(),
                    potong(b.getMaterial(),10), potong(b.getKondisi(),12), potong(b.getSumber(),10), b.getHargaPerolehan());
        }
    }

    // =============== Utilitas (private) ===============
    private Model cariById(int id) {
        for (Model b : koleksi) {
            if (b.getId() == id) return b;
        }
        return null;
    }

    private int indexById(int id) {
        for (int i = 0; i < koleksi.size(); i++) {
            if (koleksi.get(i).getId() == id) return i;
        }
        return -1;
    }

    private String potong(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max-1) + "…";
    }

    public void enterUntukLanjut() {
        System.out.print("\n~ Tekan Enter untuk melanjutkan...");
        in.nextLine();
    }

    // ===== Input helper & validasi =====
    private String inputString(String label) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Input tidak boleh kosong.");
        }
    }

    private int inputInt(String label, int min, int max) {
        while (true) {
            try {
                System.out.print(label + " : ");
                String s = in.nextLine().trim();
                int val = Integer.parseInt(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + max + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka.");
            }
        }
    }

    private double inputDouble(String label, double min, double max) {
        while (true) {
            try {
                System.out.print(label + " : ");
                String s = in.nextLine().trim();
                double val = Double.parseDouble(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + (max==Double.MAX_VALUE?"tak hingga":max) + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka (boleh desimal).");
            }
        }
    }

    private String inputStringOpsional(String label, String lama) {
        System.out.print(label + " [" + lama + "] : ");
        String s = in.nextLine().trim();
        return s.isEmpty() ? lama : s;
    }

    private Integer inputIntOpsional(String label, int lama, int min, int max) {
        while (true) {
            System.out.print(label + " [" + lama + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                int val = Integer.parseInt(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + max + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka.");
            }
        }
    }

    private Double inputDoubleOpsional(String label, double lama, double min, double max) {
        while (true) {
            System.out.print(label + " [Rp" + String.format("%,.0f", lama) + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                double val = Double.parseDouble(s);
                if (val < min || val > max) {
                    System.out.println("Harus di antara " + min + " dan " + (max==Double.MAX_VALUE?"tak hingga":max) + ".");
                } else {
                    return val;
                }
            } catch (NumberFormatException e) {
                System.out.println("Harus berupa angka (boleh desimal).");
            }
        }
    }
}
